class DevicesInventorySelectors:
    LOADER_SPINNER = "[data-testid=\"devices-loader\"]"
    HEADING_PAGE_TITLE = "[data-testid=\"heading-page-title\"]"

    DEVICE_PAGE_TITLE = "[data-testid=\"device-page-title\"]"
    ADD_DEVICE_BUTTON = "[data-testid=\"add-device-btn\"]"

    CARD_REQUIRE_ASSIGNMENTS = "[data-testid=\"card-require-assignments-tab\"]"
    CARD_REQUIRE_LICENSES = "[data-testid=\"card-require-licenses-tab\"]"
    CARD_ASSIGNED_LICENSED = "[data-testid=\"card-assigned-licensed-tab\"]"
    CARD_ALL_DEVICES = "[data-testid=\"card-all-devices-tab\"]"

    SEARCH_FIELD = "[data-testid=\"search-field\"]"
    FILTER_BUTTON = "[data-testid=\"filter-search-btn\"]"
    ACTIONS_BUTTON = "[data-testid=\"bulk-actions\"]"
    TABLE_ROWS = "[data-testid=\"table\"]>tbody>tr"
    TABLE_ROW_TEMPLATE = "[data-testid=\"table\"]>tbody>tr:nth-child({})"
