class MyApplicationsSelectors:
    LOADER_SPINNER = "[data-testid=\"loader-spinner\"]"
    HEADING_PAGE_TITLE = "[data-testid=\"heading-page-title\"]"
    REGION_DROPDOWN = "[data-testid=\"region-dropdown\"]"
    APPLICATION_TILE = "[data-testid^=\"application-tile-\"]"
