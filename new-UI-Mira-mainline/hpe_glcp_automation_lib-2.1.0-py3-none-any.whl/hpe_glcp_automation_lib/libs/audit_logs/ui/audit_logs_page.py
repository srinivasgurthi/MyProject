"""
Audit logs page object model
"""
import logging

from playwright.sync_api import expect, Page

from hpe_glcp_automation_lib.libs.audit_logs.ui.locators import AuditLogsSelectors
from hpe_glcp_automation_lib.libs.commons.ui.headered_page import HeaderedPage

log = logging.getLogger(__name__)


class AuditLogs(HeaderedPage):
    """
    Audit logs page object model class
    """

    def __init__(self, page: Page, cluster: str):
        """
        Initialize with page and cluster
        :param page: Page
        :param cluster: cluster under test url
        """
        log.info("Initialize AuditLogs page object")
        super().__init__(page, cluster)
        self.url = f"{cluster}/manage-account/auditlogs"

    def wait_for_loaded_table(self):
        """
        Wait for table rows are not empty and loader spinner is not present on the page
        :return: current instance of audit log page object
        """
        log.info("Playwright: wait for table is loaded.")
        self.wait_for_loaded_state()
        self.page.wait_for_selector(AuditLogsSelectors.AUDIT_LOGS_TABLE_ROWS, state="visible", strict=False)
        self.page.locator(AuditLogsSelectors.LOADER_SPINNER).wait_for(state="hidden")
        self.page.wait_for_load_state("domcontentloaded")
        return self

    def search_for_text(self, search_text):
        """
        Enter text to search field
        :param search_text: search_text
        :return: current instance of audit log page object
        """
        log.info(f"Playwright: search for text: '{search_text}' in audit logs")
        self.pw_utils.enter_text_into_element(AuditLogsSelectors.SEARCH_FIELD, search_text)
        self.wait_for_loaded_table()
        return self

    def close_detail_dialog(self):
        self.page.locator(AuditLogsSelectors.DETAIL_CLOSE_BUTTON).click()
        return self

    def should_have_subscr_in_table(self, search_text):
        """
        Check table row content is expected for subscriptions assignment string
        :param search_text: search_text
        :return: current instance of audit log page object
        """
        log.info(f"Playwright: check that 'DEVICE_SUBSCRIPTION_ASSIGNED' item "
                 f"with text '{search_text}' is present in table")
        subscription_item = AuditLogsSelectors.AUDIT_LOG_SM_ITEM_TEMPLATE.format(search_text)
        self.pw_utils.save_screenshot(self.test_name)
        # TODO: Refactor this class and related tests to use universal methods for table content verifications
        expect(self.page.locator(subscription_item).first).to_be_visible()
        return self

    def should_subscr_with_text_have_details(self, item_text, details_text):
        """
        Clicks on table row for subscription and check details for description on opened panel
        :param item_text: item_text
        :param details_text: details_text
        :return: current instance of audit log page object
        """
        log.info(f"Playwright: check that description in item details is correct")
        subscription_item = AuditLogsSelectors.AUDIT_LOG_SM_ITEM_TEMPLATE.format(item_text)
        self.page.locator(subscription_item).first.click()
        self.pw_utils.save_screenshot(self.test_name)
        expect(self.page.locator(AuditLogsSelectors.AUDIT_LOG_DESCRIPTION)).to_have_text(details_text)
        return self
