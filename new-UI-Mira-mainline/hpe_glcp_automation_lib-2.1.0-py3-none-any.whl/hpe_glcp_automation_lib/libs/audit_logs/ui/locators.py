class AuditLogsSelectors:
    LOADER_SPINNER = "[data-testid*=\"loader-spinner\"]"
    SEARCH_FIELD = "[data-testid=\"search-field\"]"
    AUDIT_LOGS_TABLE_ROWS = "[data-testid=\"table\"]>tbody>tr"
    AUDIT_LOG_DESCRIPTION = "[data-testid=\"heading-audit-log-details\"] div"
    DETAIL_CLOSE_BUTTON = "[data-testid=\"close-button\"]"
    AUDIT_LOG_SM_ITEM_TEMPLATE = "tr:has-text(\"Subscription Management\") td:has-text(\"{}\")"
