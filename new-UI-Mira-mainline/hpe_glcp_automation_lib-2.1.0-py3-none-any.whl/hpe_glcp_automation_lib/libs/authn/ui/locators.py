class LoginPageSelectors:
    EMAIL_ID_PATH = "id=idp-discovery-username"
    NEXT_BTN_PATH = "id=idp-discovery-submit"
    PASSWD_PATH = "id=okta-signin-password"
    SUBMIT_PATH = "id=okta-signin-submit"
