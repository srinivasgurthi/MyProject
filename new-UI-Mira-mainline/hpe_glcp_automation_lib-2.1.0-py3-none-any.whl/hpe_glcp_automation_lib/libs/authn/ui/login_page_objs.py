
"""
#TODO:
TO be refactored with new framework.
"""

class LoginPagePaths:
    email_id_path = "id=idp-discovery-username"
    next_btn_path = "id=idp-discovery-submit"
    passwd_path = "id=okta-signin-password"
    submit_path = "id=okta-signin-submit"
    cop_passwd_path = "type='password"
    cop_sign_on = "data-testid='signin"
    choose_acct = "data-testid=text-tile-title-account-"
    featured_applications = "data-testid=heading-featured_applications"
    account_search_box_xpath = 'data-testid=accounts-search-box'
    menu_item_user_button = "data-testid=drop-btn-glcp-header-all-menu-item-user"
    sign_out_button = "data-testid=text-desc-sign-out-hpe-nav-menu"
