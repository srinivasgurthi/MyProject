"""
Homepage page object model.
"""
import logging

from playwright.sync_api import Page, expect

from hpe_glcp_automation_lib.libs.commons.ui.headered_page import HeaderedPage
from hpe_glcp_automation_lib.libs.commons.ui.locators import HomePageSelectors

log = logging.getLogger(__name__)


class HomePage(HeaderedPage):
    """
    Homepage page object model class.
    """

    def __init__(self, page: Page, cluster: str):
        """
        Initialize homepage page object.
        :param page: page.
        :param cluster: cluster url.
        """
        log.info("Initialize HomePage page object")
        super().__init__(page, cluster)
        self.url = f"{cluster}/home"

    def wait_for_loaded_state(self):
        """
        Wait till page is loaded and loading spinner is not present.
        :return: current instance of Homepage page object.
        """
        log.info("Playwright: wait for home page is loaded.")
        super().wait_for_loaded_state()
        self.page.locator(HomePageSelectors.LOADER_SPINNER).wait_for(state="hidden")
        return self

    def should_have_displayed_account(self, account_name):
        """
        Verify that home page successfully loaded for particular account.
        :return: current instance of Homepage page object.
        """
        log.info("Playwright: check account name displayed at home page.")
        self.pw_utils.save_screenshot(self.test_name)
        expect(self.page.locator(HomePageSelectors.ACCT_NAME)).to_have_text(account_name)
        return self
