class NavBarSelectors:
    DASHBOARD_NAV_MENU = "[data-testid=\"dashboard-nav-menu\"]"
    APPLICATION_NAV_MENU = "[data-testid=\"application-nav-menu\"]"
    DEVICES_NAV_MENU = "[data-testid=\"devices-nav-menu\"]"
    MANAGE_NAV_MENU = "[data-testid=\"manage-nav-menu\"]"
    MENU_ITEM_USER_BUTTON = "button[data-testid=\"drop-btn-glcp-header-brand-n-profile-menu-item-user\"]," \
                            "button[data-testid=\"drop-btn-glcp-header-all-menu-item-user\"]"
    USER_MENU_POPUP = "div[data-testid=\"drop-content-glcp-header-brand-n-profile-menu-item-user\"]," \
                      "div[data-testid=\"drop-content-glcp-header-all-menu-item-user\"]"
    SIGNOUT_MENU = "data-testid=sign-out-hpe-nav-menu"


class BasePageSelectors:
    APP_LOADER = "[data-testid=\"app-loader\"]"
    LOADER_SPINNER = "[data-testid$=\"spinner-with-text\"]"


class HomePageSelectors:
    LOADER_SPINNER = "[data-testid=\"loader-spinner\"]"
    ACCT_NAME = "[data-testid=\"heading-heading-home\"]"
    INVITE_USER_BUTTON = "[data-testid=\"invite-user-card-btn\"]"
    ASSIGN_ROLES_BUTTON = "[data-testid=\"assign-user-access-card-btn\"]"
    RELEASE_NOTES_BUTTON = "[data-testid=\"release-notes-card-btn\"]"
    SWITCH_ACCOUNT_BUTTON = "[data-testid=\"switch-account-btn\"]"


class ManageAccountSelectors:
    CARD_AUDIT_LOGS = "[data-testid=\"card-audit-logs\"]"
    CARD_IDENTITY_AND_ACCESS = "[data-testid=\"card-identity\"]"
    CARD_SUBSCRIPTIONS = "[data-testid=\"card-subscriptions\"]"
    PCID_VALUE_SELECTOR = "[data-testid=\"paragraph-account-id-val\"]"


class IdentitySelectors:
    CARD_USERS = "[data-testid=\"card-users\"]"
    CARD_ROLES = "[data-testid=\"card-roles\"]"
