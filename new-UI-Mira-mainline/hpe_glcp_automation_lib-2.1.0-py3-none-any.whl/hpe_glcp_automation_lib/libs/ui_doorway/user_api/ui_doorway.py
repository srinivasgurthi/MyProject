"""
UIDoorway User API
"""
import json
import logging
import time

from hpe_glcp_automation_lib.libs.commons.user_api.ui_session import UISession

log = logging.getLogger(__name__)


class UIDoorway(UISession):
    """
    UIDoorway API Class
    """

    def __init__(self, host, user, password, pcid):
        """
        :param host: CCS UI Hostname
        :param user: Login Credentials - Username
        :param password: Login Credentials - Password
        :param pcid: Platform Customer ID

        """
        log.info("Initializing ui_doorway for user api calls")
        super().__init__(host, user, password, pcid)

        self.base_path = "/ui-doorway/ui"
        self.api_version = "/v1"

    def _get_path(self, path):
        return f"{self.base_path}{self.api_version}/{path}"

    def load_account(self, platform_customer_id):
        """
        Load into a Platform Customer Account
        :param platform_customer_id: Platform Customer ID
        :return:
        """
        self.get(f"/authn/v1/session/load-account/{platform_customer_id}")

    def sm_add_lic(self, key):
        headers = {'Content-type': 'application/json'}
        payload = {"key": key}
        result = self.post(f"{self.base_path}{self.api_version}/customers/license",
                           data=json.dumps(payload),
                           headers=headers)
        log.info("add device inventory result {}".format(result))
        return result

    def add_device_activate_inventory_emdm(self, device_list, dev_cat=None):
        """
        Add device to activate inventory
        :param device_list: list of dictionaries with devices' details (MAC-address, Serial number)
        :param dev_cat: device category
        :return:
        """
        devlist = []
        if dev_cat:
            for dev in device_list:
                new_dev = {
                    'mac_address': dev['device_1']['eth_mac'],
                    'serial_number': dev['device_1']['serial_no'],
                    'app_category': dev_cat
                }
                devlist.append(new_dev)
        devices = {'devices': devlist}
        headers = {'Content-type': 'application/json'}
        time.sleep(3)
        result = self.post(f"{self.base_path}{self.api_version}/activate/devices", data=json.dumps(devices),
                           headers=headers)
        log.info("add device inventory result {}".format(result))
        return result

    def verify_add_device_activate_inventory_emdm(self, device_list):
        """
        Add device to activate inventory
        :param device_list: list of dictionaries with devices' details (MAC-address, Serial number)
        :return:
        """
        mac = device_list[0]['device_1']['eth_mac']
        result = self.get(f"{self.base_path}{self.api_version}/activate/devices?mac_address={mac}")
        log.info("Get device inventory result {}".format(result))
        return result

    def add_device_activate_inventory(self, device_list):
        """
        Add device to activate inventory
        :param device_list: list of dictionaries with devices' details (MAC-address, Serial number)
        :return:
        """
        headers = {'Content-type': 'application/json'}
        result = self.post(f"{self.base_path}{self.api_version}/devices", data=json.dumps(device_list), headers=headers)
        log.info("add device inventory result {}".format(result))
        return result

    def list_devices(self, secondary=None):
        """
        List devices of customer in activate inventory
        :param secondary: Optional parameter, to use second get method
        :return: list of devices
        """
        if secondary:
            return self.get_secondary(f"{self.base_path}{self.api_version}/devices")
        else:
            return self.get(f"{self.base_path}{self.api_version}/devices")

    def assign_devices_to_app_in_activate_inventory(self, device_list, appid, application_instance_id):
        """
        Assign devices to app in activate inventory
        :param device_list: list of devices to be unassigned (limit 500)
            Example device_list: [{"serial_number":"APSNMR-01","device_type":"AP","part_number":"NWPRTTR01"}]
        :param appid: Application ID
        :param application_instance_id: application instance id for device assignment
        :return:
        """
        data = {
            "assign_list": [
                {
                    "devices": device_list,
                    "application_id": appid,
                    "application_instance_id": application_instance_id
                }
            ]
        }
        headers = {'Content-type': 'application/json'}
        result = self.post(f"{self.base_path}{self.api_version}/devices/application-instance", data=json.dumps(data),
                           headers=headers)
        log.info("assign devices result {}".format(result))
        return result

    def unassign_devices_from_app_in_activate_inventory(self, device_list):
        """
        Unassign devices to app in activate inventory
        :param device_list: list of devices to be unassigned (limit 500)
        :Example device_list: [{"serial_number":"APSNMR-01","device_type":"IAP","part_number":"NWPRTTR01"}]
        :return:
        """
        data = {"devices": device_list}
        headers = {'Content-type': 'application/json'}
        result = self.delete(f"{self.base_path}{self.api_version}/devices/application-instance", data=json.dumps(data),
                             headers=headers)
        log.info("unassign devices output result {}".format(result))
        return result

    def get_licenses(self, secondary=None):
        """
        List of customer licenses details of different devices
        :return: dict: list of customer license info of different devices
        Example: https://docs.ccs.arubathena.com/subscription-management/#operation/getCustomerInfoByLicenseKey

        Example: return dict: {'subscriptions':
                            [{'subscription_key': 'E18E41A85B77B4E17AF0949EE3943D38E',
                             'subscription_type': 'CENTRAL_GW',
                             'platform_customer_id': 'eb54bcb4a92611eb80665a60b9b8547a',
                              'application_customer_id': None,
                               'appointments': {'subscription_start': 1620267113000,
                                'subscription_end': 1628043113000,
                                'activation_date': 1620267174238,
                                'suspension_date': None, 'reactivation_date': None,
                                'cancellation_date': None, 'duration': None},
                                'product_sku': 'JZ121-EVALS',
                                'product_description': 'Aruba 70XX Gateway Foundation 90d Sb E-STU',
                                'evaluation_type': 'EVAL',
                                'license_tier': 'FOUNDATION',
                                'subscription_tier': 'FOUNDATION_70XX',
                                'attributes': [],
                                'quantity': 10,
                                'available_quantity': 10,
                                'support_attributes': []}
        """

        log.info("get_licenses: Listing licensing information for customer")
        log.info(f"Executing GET on request URL: {self.base_path}{self.api_version}/license/devices")
        if secondary:
            return self.post_secondary(f"{self.base_path}{self.api_version}/license")
        else:
            return self.post(f"{self.base_path}{self.api_version}/license")

    def assign_license_to_devices(self, license_device_tupl_list, device_type, part_number):
        """
        Assign device to respective license
        :param license_device_tupl_list: List of tuple of serial number and subscription key
        :param device_type: Type of device used to be assigned
        :param part_number: Device part number
        :return:
         """
        log.info(f"assign_license_to_devices: license assignment triggered with input {license_device_tupl_list}")

        data = []
        headers = {'Content-type': 'application/json'}
        for (device, license) in license_device_tupl_list:
            license_data = {
                "serial_number": device,
                "subscription_key": license,
                "device_type": device_type,
                "part_number": part_number
            }
            data.append(license_data)

        resp = None
        for index in range(3):
            resp = self.post(f"{self.base_path}{self.api_version}/license/devices", json=data, headers=headers)
            if resp[0]['status'] == 'SUCCESS':
                log.info("license response for device_type: {}, {}".format(device_type, resp))
                return resp
            else:
                log.warning("assign license output result {}".format(resp))
                time.sleep(5)
        log.info("assign license output result {}".format(resp))

    def unassign_license_from_devices(self, device_serial_list):
        """
        Unassign license from list of devices under device inventory
        :param device_serial_list: List of device serials license to be unassigned from
        :return:
        """
        headers = {'Content-type': 'application/json'}
        log.info(f"unassign_license_from_devices: license unassignment triggered with input {device_serial_list}")
        result = self.delete(
            f"{self.base_path}{self.api_version}/license/devices?device_serials={','.join(device_serial_list)}",
            headers=headers)
        log.info("unassign license output result {}".format(result))
        return result

    def get_device_license(self, secondary=None):
        if secondary:
            return self.get_secondary(f"{self.base_path}{self.api_version}/license/devices")
        else:
            return self.get(f"{self.base_path}{self.api_version}/license/devices")

    def delete_application_customer(self, app_cust_id):
        """
        Delete or Un-provision the app for the customer
        :param app_cust_id: Application customer id
        :return:
        """
        data = {"action": "UNPROVISION"}
        if app_cust_id:
            return self.patch(
                f"/app-provision/ui/v1/provisions/{app_cust_id}", json=data
            )

    def get_provisions(self, secondary=None):
        """
        :return: Provision Apps details
        """
        if secondary:
            return self.get_secondary(f"{self.base_path}{self.api_version}/applications/provisions")
        else:
            return self.get(f"{self.base_path}{self.api_version}/applications/provisions")

    def get_account_contact(self, secondary=None):
        if secondary:
            return self.get_secondary(f"/accounts/ui/v1/customer/profile/contact")
        else:
            return self.get(f"/accounts/ui/v1/customer/profile/contact")

    def verify_claim_device(self, sub_key):
        """
        :return: Provision Apps details
        """
        data = {'key': sub_key}
        res = self.post(f"/{self.base_path}{self.api_version}customers/license", json=data)
        return res

    def apply_subscription_key(self, sub_key):
        """
        :return: Provision Apps details
        """
        data = {'key': sub_key}
        res = self.post(f"{self.base_path}{self.api_version}/customers/license", json=data)
        return res

    def provision_application(self, region, appid):
        """
        Create an Application Customer ID for an App
        :param region: CCS Region code
        :param appid: Application ID which need to provision
        :return: Application Customer ID
        :appid: ...
        """
        data = {
            "application_id": appid,
            "region": region,
            "action": "PROVISION"
        }
        res = self.post("/app-provision/ui/v1/provisions", json=data)
        return res

    def wait_for_provision_status(self, app_cust_id, status, iterations=30, delay=6):
        """
        Wait for the Application Customer ID's status to reach the expected state
        :param app_cust_id: Application Customer ID that need to be queried
        :param status: Status value to be checked for
        :param iterations: No of times to check
        :param delay: Delay between the iterations
        :return: (True/False)
        """
        for iteration in range(1, iterations + 1):
            try:
                res = self.get(f"/app-provision/ui/v1/provisions/{app_cust_id}")
            except Exception as e:
                if status == "UNPROVISIONED" and e.response.status_code == 404:
                    log.info(f"The status of customer reached '{status}'")
                    return True
                else:
                    raise e
            else:
                if status != "UNPROVISIONED" and res["provision_status"] == status:
                    log.info(f"The status of customers reached '{status}'")
                    return True
            time.sleep(delay)
            log.info(f"Waited for {iteration * delay} seconds for status change")

        log.error(f"The customer {app_cust_id} did not attain '{status}' status")
